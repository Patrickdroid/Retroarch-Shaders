Settings for the guest-advanced shader by Nesguy of the Retroarch forums. 

Installation: place the shader preset files in RetroArch -> shaders

These presets are intended for use on a 1080p display utilizing any known subpixel structure. The only caveat is that they may be somewhat dark on an LCD without adjusting the display backlight. It is recommended that you adjust the display backlight to the maximum setting to get the best results. 

aperture: emulates a 540 TVL aperture grille with an RGB video signal 
ntsc-360-TVL: emulates a 360 TVL slotmask with an NTSC composite video signal
ntsc-540-TVL: emulates a 540 TVL slotmask with an NTSC composite video signal
rgb-360-TVL: emulates a 360 TVL slotmask with an RGB video signal
rgb-540-TVL: emulates a 540 TVL slotmask with an RGB video signal

Any of the slotmasks can be altered to display an aperture grille by setting "slotmask" and "slotmask1" to 0.00. In the shader menu settings these are called "Slot Mask Strength Bright Pixels" and "Slot Mask Strength Dark Pixels." You may then need to lower the backlight setting on the display or adjust the bright boost settings to get a more accurate brightness level. 



